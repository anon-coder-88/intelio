import {notFound} from 'next/navigation';
import {sampleApps} from '@/lib/domain';
import IntelioApp from '@/components/intelio-app';
const titles:Record<string,string>={explore:'Explore applications',apps:'Application profile',models:'Model capabilities',playground:'AI playground',workspace:'Demo workspace',economy:'Resource economy',token:'Intelio token',docs:'Developer documentation',whitepaper:'Whitepaper',disclosures:'Disclosures'};
export async function generateMetadata({params}:{params:Promise<{slug:string[]}>}){const {slug}=await params;return {title:`${titles[slug[0]]||'Not found'} · Intelio`,description:'Explore Intelio applications, intelligence, tools and programmable resources.'};}
export default async function Page({params}:{params:Promise<{slug:string[]}>}){const {slug}=await params;if(!((slug.length===1&&titles[slug[0]]&&slug[0]!=='apps')||(slug.length===2&&(slug[0]==='workspace'||(slug[0]==='apps'&&sampleApps.some(a=>a.id===slug[1]))))))notFound();return <IntelioApp path={'/'+slug.join('/')}/>;}
