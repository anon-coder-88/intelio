import IntelioApp from '@/components/intelio-app';
export default function NotFound(){return <IntelioApp path="/not-found"/>;}
