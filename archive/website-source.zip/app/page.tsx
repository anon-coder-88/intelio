import IntelioApp from '@/components/intelio-app';
export default function Home(){return <IntelioApp path="/"/>;}
