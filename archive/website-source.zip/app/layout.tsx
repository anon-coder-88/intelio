import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Intelio · Give AI applications the resources to operate",
  description: "Explore connected intelligence, tools and programmable resources on Robinhood Chain. Configure an application in Intelio's local demo workspace.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
