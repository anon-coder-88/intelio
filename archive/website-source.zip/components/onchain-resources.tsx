'use client';
import {PageHead} from './shell';
export default function OnchainResources() {
  return <div className="container inner-page"><PageHead eyebrow="ONCHAIN MVP" title="Application resources." description="Register an application identity, fund its ETH budget, and configure authorized usage payments."/><iframe src="/onchain/index.html" title="Intelio onchain resource controls" className="onchain-frame"/></div>;
}
