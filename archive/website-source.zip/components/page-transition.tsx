'use client';

import {useEffect,useRef,useState} from 'react';

type Phase='intro'|'idle'|'outro';
const browserNavigate=(url:string)=>window.location.assign(url);
export function goToPage(url:string){
 const request=new CustomEvent<string>('intelio:navigate',{detail:url,cancelable:true});
 if(window.dispatchEvent(request))window.location.assign(url);
}

export default function PageTransition({navigate=browserNavigate}:{navigate?:(url:string)=>void}){
 const [phase,setPhase]=useState<Phase>('intro');
 const current=useRef<Phase>('intro');
 const timer=useRef<ReturnType<typeof setTimeout>|null>(null);

 useEffect(()=>{
  const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finish=()=>{current.current='idle';setPhase('idle');};
  timer.current=setTimeout(finish,reduced?0:1150);

  const begin=(url:string)=>{
   if(current.current!=='idle')return false;
   if(reduced){navigate(url);return true;}
   current.current='outro';setPhase('outro');
   document.documentElement.dataset.pageLeaving='true';
   timer.current=setTimeout(()=>navigate(url),520);
   return true;
  };
  const onClick=(event:MouseEvent)=>{
   if(event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.altKey||event.shiftKey)return;
   const target=event.target;
   if(!(target instanceof Element))return;
   const link=target.closest<HTMLAnchorElement>('a[href]');
   if(!link||link.hasAttribute('download')||(link.target&&link.target!=='_self')||link.dataset.noTransition!==undefined)return;
   let next:URL;
   try{next=new URL(link.href,window.location.href);}catch{return;}
   if(next.origin!==window.location.origin||!['http:','https:'].includes(next.protocol))return;
   const here=new URL(window.location.href);
   if(next.pathname===here.pathname&&next.search===here.search)return;
   if(begin(next.href))event.preventDefault();
  };
  const onNavigate=(event:Event)=>{
   const request=event as CustomEvent<string>;
   let next:URL;
   try{next=new URL(request.detail,window.location.href);}catch{return;}
   if(next.origin!==window.location.origin||!['http:','https:'].includes(next.protocol))return;
   if(begin(next.href))event.preventDefault();
  };

  const onPageShow=(event:PageTransitionEvent)=>{
   if(!event.persisted)return;
   if(timer.current)clearTimeout(timer.current);
   delete document.documentElement.dataset.pageLeaving;
   current.current='intro';setPhase('intro');
   timer.current=setTimeout(finish,reduced?0:1150);
  };
  document.addEventListener('click',onClick);
  window.addEventListener('intelio:navigate',onNavigate);
  window.addEventListener('pageshow',onPageShow);
  return()=>{
   if(timer.current)clearTimeout(timer.current);
   document.removeEventListener('click',onClick);
   window.removeEventListener('intelio:navigate',onNavigate);
   window.removeEventListener('pageshow',onPageShow);
   delete document.documentElement.dataset.pageLeaving;
  };
 },[navigate]);

 return <div className={'page-transition '+phase} aria-hidden="true">
  <div className="transition-shutter top"/><div className="transition-shutter bottom"/>
  <div className="transition-scene">
   <div className="transition-grid"/>
   <div className="transition-stream stream-one"/><div className="transition-stream stream-two"/><div className="transition-stream stream-three"/>
   <div className="transition-emblem"><span className="emblem-orbit"/><img src="/favicon.svg" width="72" height="72" alt=""/></div>
   <div className="transition-name">INTELIO</div>
   <div className="transition-caption">INTELLIGENCE <span>·</span> TOOLS <span>·</span> RESOURCES</div>
   <div className="transition-track"><span/></div>
   <div className="transition-index">01 / 03 <span>CONNECTING THE SYSTEM</span></div>
  </div>
 </div>;
}
