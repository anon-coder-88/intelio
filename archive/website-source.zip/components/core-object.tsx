'use client';
import {useEffect,useRef,useState} from 'react';
import {Pause,Play,Rotate3D} from 'lucide-react';
export default function CoreObject({active=0}:{active?:number}){
 const host=useRef<HTMLDivElement>(null);const [paused,setPaused]=useState(false);const [fallback,setFallback]=useState(false);const [ready,setReady]=useState(false);const control=useRef({active,paused,visible:true});const wake=useRef(()=>{});
 useEffect(()=>{control.current.active=active;control.current.paused=paused;wake.current();},[active,paused]);
 useEffect(()=>{
  let clean=()=>{};let dead=false;
  if(window.matchMedia('(prefers-reduced-motion: reduce)').matches){setFallback(true);return;}
  import('three').then(T=>{
   if(dead||!host.current)return;const el=host.current;
   const scene=new T.Scene();const camera=new T.PerspectiveCamera(35,1,.1,100);camera.position.set(0,.3,9.6);
   let renderer:InstanceType<typeof T.WebGLRenderer>;try{renderer=new T.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});}catch{setFallback(true);return;}
   renderer.setPixelRatio(Math.min(window.devicePixelRatio,1.6));renderer.setClearColor(0x090f13,0);renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.6;
   el.appendChild(renderer.domElement);renderer.domElement.setAttribute('aria-hidden','true');
   const group=new T.Group();scene.add(group);group.rotation.set(.12,-.48,-.09);
   const metal=new T.MeshStandardMaterial({color:0x859da3,metalness:.75,roughness:.23,emissive:0x1b3a37,emissiveIntensity:.14});const graphite=new T.MeshStandardMaterial({color:0x16272d,metalness:.75,roughness:.23});
   const mint=new T.MeshStandardMaterial({color:0x80e3c0,emissive:0x80e3c0,emissiveIntensity:1,metalness:.3,roughness:.2});
   function rounded(w:number,h:number,r:number){const s=new T.Shape();s.moveTo(-w/2+r,-h/2);s.lineTo(w/2-r,-h/2);s.quadraticCurveTo(w/2,-h/2,w/2,-h/2+r);s.lineTo(w/2,h/2-r);s.quadraticCurveTo(w/2,h/2,w/2-r,h/2);s.lineTo(-w/2+r,h/2);s.quadraticCurveTo(-w/2,h/2,-w/2,h/2-r);s.lineTo(-w/2,-h/2+r);s.quadraticCurveTo(-w/2,-h/2,-w/2+r,-h/2);return s;}
   const shape=rounded(2.7,3.7,.48);const hole=rounded(2.18,3.18,.35);shape.holes.push(new T.Path(hole.getPoints()));
   const geo=new T.ExtrudeGeometry(shape,{depth:.45,bevelEnabled:true,bevelThickness:.07,bevelSize:.08,bevelSegments:4,steps:1,curveSegments:20});geo.center();group.add(new T.Mesh(geo,metal));
   for(const z of [-.54,.4])group.add(new T.Mesh(new T.TubeGeometry(new T.CatmullRomCurve3(rounded(2.68,3.67,.46).getPoints(64).map(p=>new T.Vector3(p.x,p.y,z)),true),180,.018,6,true),mint));
   group.add(new T.Mesh(new T.CylinderGeometry(.46,.46,2.55,40),graphite));
   group.add(new T.Mesh(new T.CylinderGeometry(.49,.49,2.5,40),new T.MeshPhysicalMaterial({color:0x80e3c0,metalness:.08,roughness:.07,transparent:true,opacity:.17,side:T.DoubleSide})));
   const spine=new T.Mesh(new T.CylinderGeometry(.105,.105,2.7,24),mint);spine.position.z=.48;group.add(spine);
   for(const y of [-1.33,-.75,.75,1.33]){const ring=new T.Mesh(new T.TorusGeometry(.47,.075,10,40),metal);ring.rotation.x=Math.PI/2;ring.position.y=y;group.add(ring);}
   const curves=[new T.CatmullRomCurve3([new T.Vector3(0,1.32,.05),new T.Vector3(0,2.25,.05),new T.Vector3(.5,2.75,.05),new T.Vector3(2.8,3.05,.05)]),new T.CatmullRomCurve3([new T.Vector3(.4,0,.05),new T.Vector3(1.6,0,.05),new T.Vector3(2.25,-.4,.05),new T.Vector3(3.05,-.4,.05)]),new T.CatmullRomCurve3([new T.Vector3(0,-1.32,.05),new T.Vector3(0,-2.2,.05),new T.Vector3(-.55,-2.6,.05),new T.Vector3(-2.4,-2.9,.05)])];
   const accents=[0x80e3c0,0xbfaaff,0xffd28c];
   const paths=curves.map((curve,i)=>{const material=new T.MeshStandardMaterial({color:accents[i],emissive:accents[i],emissiveIntensity:.25,metalness:.22,roughness:.18});const mesh=new T.Mesh(new T.TubeGeometry(curve,70,.045,8,false),material);group.add(mesh);return mesh;});
   const dots=curves.map((_,i)=>{const m=new T.Mesh(new T.SphereGeometry(.09,16,16),new T.MeshBasicMaterial({color:accents[i]}));group.add(m);return m;});
   const halo=new T.Mesh(new T.TorusGeometry(.78,.009,6,96),new T.MeshBasicMaterial({color:0x80e3c0,transparent:true,opacity:.32}));halo.position.z=.32;group.add(halo);
   scene.add(new T.HemisphereLight(0xe8fff8,0x07131c,2.2));for(const [color,intensity,x,y,z] of [[0x80e3c0,30,-3,3,4],[0xbfaaff,22,4,-1,3],[0xffffff,30,1,5,-2]]){const light=new T.PointLight(color,intensity);light.position.set(x,y,z);scene.add(light);}
   const resize=()=>{const {width,height}=el.getBoundingClientRect();if(!width||!height)return;renderer.setSize(width,height);camera.aspect=width/height;camera.updateProjectionMatrix();};resize();const ro=new ResizeObserver(resize);ro.observe(el);
   const observer=new IntersectionObserver(([entry])=>{control.current.visible=entry.isIntersecting;wake.current();});observer.observe(el);
   let raf=0;let t=0;let lastFrame=0;let dragging=false;let last=0;let offset=0;
   const down=(e:PointerEvent)=>{dragging=true;last=e.clientX;renderer.domElement.setPointerCapture(e.pointerId);};const move=(e:PointerEvent)=>{if(dragging){offset+=(e.clientX-last)*.008;last=e.clientX;wake.current();}};const up=()=>dragging=false;
   renderer.domElement.addEventListener('pointerdown',down);renderer.domElement.addEventListener('pointermove',move);renderer.domElement.addEventListener('pointerup',up);
   const lose=(e:Event)=>{e.preventDefault();setFallback(true);};renderer.domElement.addEventListener('webglcontextlost',lose);
   const loop=(now=performance.now())=>{raf=0;if(dead||document.hidden||!control.current.visible){lastFrame=0;return;}if(!control.current.paused)t+=Math.min(.05,lastFrame?(now-lastFrame)/1000:0)*.75;lastFrame=now;group.rotation.y=-.48+Math.sin(t*.3)*.12+offset;group.rotation.x=.12+Math.sin(t*.22)*.045;group.position.y=Math.sin(t*.65)*.08;halo.rotation.z=t*.07;paths.forEach((p,i)=>{const target=control.current.active===i?2.1:.3;p.material.emissiveIntensity+=(target-p.material.emissiveIntensity)*.09;dots[i].position.copy(curves[i].getPointAt((t*.13+i*.22)%1));dots[i].scale.setScalar(control.current.active===i?1.2:0.78);});renderer.render(scene,camera);if(!control.current.paused)raf=requestAnimationFrame(loop);};wake.current=()=>{cancelAnimationFrame(raf);loop();};document.addEventListener('visibilitychange',wake.current);loop();setReady(true);
   clean=()=>{cancelAnimationFrame(raf);document.removeEventListener('visibilitychange',wake.current);wake.current=()=>{};ro.disconnect();observer.disconnect();scene.traverse(o=>{if(o instanceof T.Mesh){o.geometry.dispose();if(Array.isArray(o.material))o.material.forEach(m=>m.dispose());else o.material.dispose();}});renderer.dispose();renderer.domElement.remove();};
  }).catch(()=>setFallback(true));return()=>{dead=true;clean();};
 },[]);
 return <div className="core-wrap"><div className="core-grid" aria-hidden="true"/>{fallback?<img className="core-poster" src="/brand/core.png" alt="Graphite application core linked by three mint resource paths"/>:<div className="core-canvas" ref={host}/>}<div className={"object-label label-top "+(active===0?"selected":"")}><span>01</span> Intelligence</div><div className={"object-label label-right "+(active===1?"selected":"")}><span>02</span> Tools</div><div className={"object-label label-bottom "+(active===2?"selected":"")}><span>03</span> Resources</div>{!fallback&&<div className="core-toolbar"><span><Rotate3D size={14}/>{ready?'Drag to explore':'Initializing core'}</span><button onClick={()=>setPaused(x=>!x)} aria-label={paused?'Resume animation':'Pause animation'}>{paused?<Play size={14}/>:<Pause size={14}/>}</button></div>}</div>;
}
