'use client';
import {useState,Component,type ReactNode} from 'react';
import {useConnection} from 'wagmi';
import {Header,Footer,Empty,ButtonLink} from './shell';
import {WalletProvider,WalletDialog} from './wallet';
import Home from './home';
import OnchainResources from './onchain-resources';
import Catalog,{AppProfile} from './catalog';
import {WorkspaceList,WorkspaceEditor} from './workspace';
import Economy from './economy';
import Playground from './playground';
import {ContentPage} from './content';
import PageTransition from './page-transition';
class FeatureBoundary extends Component<{children:ReactNode},{failed:boolean}>{state={failed:false};static getDerivedStateFromError(){return {failed:true};}render(){return this.state.failed?<div className="container inner-page"><Empty title="This view couldn’t finish loading." text="Your saved drafts remain in this browser. Reload to try again."><button className="button" onClick={()=>location.reload()}>Reload page</button><ButtonLink href="/">Return home</ButtonLink></Empty></div>:this.props.children;}}
function App({path}:{path:string}){const [wallet,setWallet]=useState(false);const {address}=useConnection();const route=path.replace(/\/$/,'')||'/';let content:ReactNode;
 if(route==='/resources')content=<OnchainResources/>;else if(route==='/')content=<Home/>;else if(route==='/explore')content=<Catalog/>;else if(route==='/models')content=<Catalog models/>;else if(/^\/apps\/[^/]+$/.test(route))content=<AppProfile id={route.split('/')[2]}/>;else if(route==='/workspace')content=<WorkspaceList/>;else if(/^\/workspace\/[^/]+$/.test(route))content=<WorkspaceEditor id={route.split('/')[2]}/>;else if(route==='/economy')content=<Economy/>;else if(route==='/playground')content=<Playground/>;else if(['/docs','/token','/whitepaper','/disclosures'].includes(route))content=<ContentPage page={route.slice(1)}/>;else content=<div className="container inner-page"><Empty title="This path is still unexplored." text="The page you requested does not exist."><ButtonLink href="/">Return home</ButtonLink></Empty></div>;
 return <><PageTransition/><a className="skip-link" href="#main">Skip to content</a><Header path={route} address={address} onWallet={()=>setWallet(true)}/><main id="main"><FeatureBoundary>{content}</FeatureBoundary></main><Footer/><WalletDialog open={wallet} onClose={()=>setWallet(false)}/></>;
}
export default function IntelioApp({path}:{path:string}){return <WalletProvider><App path={path}/></WalletProvider>;}
