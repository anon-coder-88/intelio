import {pipeline,env} from 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@4.3.0/dist/transformers.web.min.js';
const MODEL_ID='Xenova/distilbert-base-uncased-finetuned-sst-2-english';
env.allowLocalModels=false;
if(env.backends.onnx.wasm)env.backends.onnx.wasm.numThreads=1;
const scope=self;
let classifier=null;
scope.onmessage=async(e)=>{try{
 if(e.data.type==='load'){
  classifier=await pipeline('text-classification',MODEL_ID,{dtype:'q8',device:'wasm',progress_callback:(data)=>scope.postMessage({type:'progress',file:data.file||'',progress:data.progress??0,status:data.status})});
  scope.postMessage({type:'ready',model:MODEL_ID});
 }else if(e.data.type==='run'){
  if(!classifier)throw Error('Load the model before running classification.');
  const output=await classifier(e.data.text,{top_k:null});scope.postMessage({type:'result',output,model:MODEL_ID});
 }
}catch(e){scope.postMessage({type:'error',message:e instanceof Error?e.message:'The local model could not run.'});}};
