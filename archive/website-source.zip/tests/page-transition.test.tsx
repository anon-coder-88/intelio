import test from 'node:test';
import assert from 'node:assert/strict';
import React,{act} from 'react';
// @ts-expect-error jsdom is a local test harness dependency.
import {JSDOM,VirtualConsole} from 'jsdom';
import {createRoot} from 'react-dom/client';
import PageTransition from '../components/page-transition';
const dom=new JSDOM('<div id="root"></div>',{url:'https://intelio.example/explore',virtualConsole:new VirtualConsole()});
for(const key of ['window','document','Element','HTMLElement','MouseEvent','Event','CustomEvent','location'])Object.defineProperty(globalThis,key,{value:(dom.window as any)[key],configurable:true});
Object.assign(globalThis,{React,IS_REACT_ACT_ENVIRONMENT:true});
const pause=(ms:number)=>act(async()=>{await new Promise(r=>setTimeout(r,ms));});
function click(href:string,options:MouseEventInit={},attributes:Record<string,string>={}){const link=document.createElement('a');link.href=href;for(const [key,value] of Object.entries(attributes))link.setAttribute(key,value);document.body.appendChild(link);const event=new MouseEvent('click',{bubbles:true,cancelable:true,button:0,...options});link.dispatchEvent(event);link.remove();return event.defaultPrevented;}
test('entrance clears; only ordinary internal navigation waits for the exit sequence; bfcache recovers',async()=>{
 window.matchMedia=()=>({matches:false} as any);
 const root=createRoot(document.getElementById('root')!);const destinations:string[]=[];const navigate=(url:string)=>destinations.push(url);
 await act(async()=>root.render(<PageTransition navigate={navigate}/>));
 assert(document.querySelector('.page-transition.intro'));
 await pause(1180);assert(document.querySelector('.page-transition.idle'));
 for(const [href,options,attrs] of [['#main',{},{}],['https://elsewhere.example/',{},{}],['/models',{metaKey:true},{}],['/docs',{}, {target:'_blank'}],['/token',{}, {download:'file'}]] as const)assert.equal(click(href,options,attrs),false,href);
 await act(async()=>{assert.equal(click('/economy'),true);});assert(document.querySelector('.page-transition.outro'));assert.equal(document.documentElement.dataset.pageLeaving,'true');
 assert.equal(click('/docs'),false);assert.equal(destinations.length,0);
 await pause(550);assert.deepEqual(destinations,['https://intelio.example/economy']);
 const pageshow=new Event('pageshow');Object.defineProperty(pageshow,'persisted',{value:true});await act(async()=>window.dispatchEvent(pageshow));assert(document.querySelector('.page-transition.intro'));assert.equal(document.documentElement.dataset.pageLeaving,undefined);
 await pause(1180);assert(document.querySelector('.page-transition.idle'));
 const programmatic=new CustomEvent('intelio:navigate',{detail:'/workspace/test',cancelable:true});await act(async()=>window.dispatchEvent(programmatic));assert(programmatic.defaultPrevented);assert(document.querySelector('.page-transition.outro'));
 await pause(550);assert.deepEqual(destinations,['https://intelio.example/economy','https://intelio.example/workspace/test']);
 await act(async()=>root.unmount());
});
test('reduced motion navigates immediately',async()=>{
 window.matchMedia=()=>({matches:true} as any);
 const host=document.createElement('div');document.body.appendChild(host);const root=createRoot(host);const destinations:string[]=[];const navigate=(url:string)=>destinations.push(url);
 await act(async()=>root.render(<PageTransition navigate={navigate}/>));await pause(5);
 await act(async()=>{assert.equal(click('/workspace/new'),true);});assert.deepEqual(destinations,['https://intelio.example/workspace/new']);
 assert.equal(document.documentElement.dataset.pageLeaving,undefined);
 await act(async()=>root.unmount());host.remove();
});
