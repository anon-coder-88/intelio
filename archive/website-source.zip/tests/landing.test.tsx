import test from 'node:test';
import assert from 'node:assert/strict';
import React,{act} from 'react';
// @ts-expect-error jsdom is a local test harness dependency.
import {JSDOM} from 'jsdom';
import {createRoot} from 'react-dom/client';
import Home from '../components/home';
const dom=new JSDOM('<div id="root"></div>',{url:'https://intelio.example/'});
for(const key of ['window','document','HTMLElement','Element','Event','MouseEvent','location'])Object.defineProperty(globalThis,key,{value:(dom.window as any)[key],configurable:true});
Object.assign(globalThis,{React,IS_REACT_ACT_ENVIRONMENT:true,innerHeight:900,requestAnimationFrame:(fn:()=>void)=>setTimeout(fn,16),cancelAnimationFrame:(id:number)=>clearTimeout(id),IntersectionObserver:class{constructor(_cb:any,_opts:any){}observe(){}unobserve(){}disconnect(){}}});
window.matchMedia=()=>({matches:true,addListener(){},removeListener(){}} as any);
const root=createRoot(document.getElementById('root')!);
test('landing architecture tabs update content and point to working routes; reduced motion keeps content visible',async()=>{
 await act(async()=>root.render(<Home/>));
 const tabs=[...document.querySelectorAll<HTMLButtonElement>('.capability-tabs button')];assert.equal(tabs.length,3);
 assert.equal(tabs[0].getAttribute('aria-selected'),'true');assert.equal(document.querySelector<HTMLAnchorElement>('#capability-description a')!.getAttribute('href'),'/models');
 await act(async()=>tabs[1].click());assert.equal(tabs[1].getAttribute('aria-selected'),'true');assert.match(document.querySelector('#capability-description')!.textContent||'',/Tools, within reach/);assert.equal(document.querySelector<HTMLAnchorElement>('#capability-description a')!.getAttribute('href'),'/workspace');
 await act(async()=>tabs[2].click());assert.equal(document.querySelector<HTMLAnchorElement>('#capability-description a')!.getAttribute('href'),'/economy');
 const links=[...document.querySelectorAll<HTMLAnchorElement>('.landing a')].map(a=>a.getAttribute('href'));for(const route of ['/workspace','/economy','/explore','/playground','/docs','/whitepaper'])assert(links.includes(route),route);
 assert.equal(document.querySelector<HTMLElement>('.landing')!.dataset.motionReady,undefined);
 await act(async()=>root.unmount());
});
