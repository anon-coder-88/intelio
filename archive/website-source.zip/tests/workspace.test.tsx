import test from 'node:test';
import assert from 'node:assert/strict';
import React,{act} from 'react';
// @ts-expect-error jsdom is used only in the local test harness.
import {JSDOM} from 'jsdom';
import {createRoot} from 'react-dom/client';
import {WorkspaceEditor} from '../components/workspace';
import {blankDraft,writeDraft,readRuns,toolsCatalog} from '../lib/domain';
const dom=new JSDOM('<div id="root"></div>',{url:'https://intelio.example/workspace/test'});
for(const k of ['window','document','localStorage','sessionStorage','location','HTMLElement','HTMLInputElement','Event','MouseEvent'])Object.defineProperty(globalThis,k,{value:(dom.window as any)[k],configurable:true});
Object.assign(globalThis,{React,IS_REACT_ACT_ENVIRONMENT:true});
const root=createRoot(document.getElementById('root')!);
const click=async(label:string)=>{const el=[...document.querySelectorAll('button')].find(x=>x.textContent?.trim()===label);assert(el,`button ${label}`);await act(async()=>el.click());};
const wait=async(ms:number)=>act(async()=>{await new Promise(r=>setTimeout(r,ms));});
test('workspace prevents duplicate runs, pauses and cancels, records zero cost for denied tools',async()=>{const d={...blankDraft(),name:'Test',id:'test'};writeDraft(d);await act(async()=>root.render(<WorkspaceEditor id="test"/>));await click('Start demo run');assert.equal(readRuns().length,1);assert(document.querySelector<HTMLButtonElement>('button:disabled'));await wait(1400);assert.equal(readRuns()[0].state,'blocked');assert.equal(readRuns()[0].steps[0].cost,0);
 await act(async()=>root.render(<div/>));sessionStorage.clear();writeDraft({...d,tools:[...toolsCatalog]});await act(async()=>root.render(<WorkspaceEditor id="test"/>));await click('Start demo run');await click('Pause');await wait(1400);assert.equal(readRuns()[0].steps.length,0);await click('Resume');await wait(1400);assert.equal(readRuns()[0].steps.length,1);assert.equal(readRuns()[0].steps[0].cost,8);await click('Cancel run');await wait(1400);assert.equal(readRuns()[0].steps.length,1);assert.equal(readRuns()[0].state,'cancelled');await act(async()=>root.unmount());});
