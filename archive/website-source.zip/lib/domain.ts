export const APP_KEY = 'intelio.drafts.v1';
export const RUN_KEY = 'intelio.runs.v1';
export const WHITEPAPER='https://docs.google.com/document/d/1nQRdGygmIRkQKCf7jCK8AlRhggVlXCcQ_NTc8Jmp04g/edit?usp=sharing';
export const MODEL_ID='Xenova/distilbert-base-uncased-finetuned-sst-2-english';
export const toolsCatalog=['Web research','Chain monitor','Code analysis'];
export const capabilities=['Text generation','Classification','Code assistance','Embeddings'];
export type Draft={schemaVersion:1;mode:'demo';id:string;name:string;description:string;url:string;models:string[];tools:string[];balance:number;requestLimit:number;dailyLimit:number;tokenName:string;tokenSymbol:string;tokenSupply:string;updatedAt:string};
export type Step={service:string;tool:string;cost:number;description:string};
export type Usage={service:string;cost:number;outcome:'completed'|'blocked';reason:string;at:string};
export type Run={id:string;draftId:string;name:string;state:'running'|'paused'|'completed'|'blocked'|'cancelled';index:number;steps:Usage[];policy:Draft;startedAt:string};
export const steps:Step[]=[{service:'Research context',tool:'Web research',cost:8,description:'Gather a sample research context'},{service:'Classify sources',tool:'Web research',cost:5,description:'Classify the sample findings'},{service:'Review chain activity',tool:'Chain monitor',cost:12,description:'Inspect illustrative onchain activity'},{service:'Build a summary',tool:'Code analysis',cost:10,description:'Prepare a simulated structured report'}];
export function blankDraft():Draft{return {schemaVersion:1,mode:'demo',id:crypto.randomUUID(),name:'',description:'',url:'',models:['Classification'],tools:[],balance:100,requestLimit:20,dailyLimit:60,tokenName:'',tokenSymbol:'',tokenSupply:'',updatedAt:new Date().toISOString()};}
export function validateDraft(d:Draft):Record<string,string>{
 const e:Record<string,string>={};
 if(typeof d.name!=='string'||!d.name.trim()||d.name.length>80)e.name='Enter a name of 1–80 characters.';
 if(typeof d.description!=='string'||d.description.length>600)e.description='Use up to 600 characters.';
 if(d.url){try{if(new URL(d.url).protocol!=='https:')throw Error();}catch{e.url='Use a valid HTTPS URL.';}}
 for(const k of ['balance','requestLimit','dailyLimit'] as const)if(!Number.isSafeInteger(d[k])||d[k]<0||d[k]>1e9)e[k]='Enter a whole number from 0 to 1,000,000,000.';
 if(d.requestLimit>d.dailyLimit)e.requestLimit='Request limit cannot exceed daily limit.';
 if(d.dailyLimit>d.balance)e.dailyLimit='Daily limit cannot exceed allocated demo resources.';
 if(!Array.isArray(d.models)||d.models.some(x=>!capabilities.includes(x)))e.models='Choose only the available capabilities.';
 if(!Array.isArray(d.tools)||d.tools.some(x=>!toolsCatalog.includes(x)))e.tools='Choose only the available tools.';
 if(d.tokenSymbol.length>12||d.tokenName.length>80)e.tokenName='Token name: up to 80 characters; symbol: up to 12.';
 if(d.tokenSupply&&!/^\d{1,18}$/.test(d.tokenSupply))e.tokenSupply='Enter a nonnegative whole number (up to 18 digits).';
 return e;
}
export function parseDraft(text:string):Draft{
 if(new TextEncoder().encode(text).length>1_000_000)throw Error('Import is limited to 1 MB.');
 let d:any;try{d=JSON.parse(text);}catch{throw Error('This file is not valid JSON.');}
 const keys=['schemaVersion','mode','id','name','description','url','models','tools','balance','requestLimit','dailyLimit','tokenName','tokenSymbol','tokenSupply','updatedAt'];
 if(!d||typeof d!=='object'||Array.isArray(d)||Object.keys(d).some(x=>!keys.includes(x))||keys.some(x=>!(x in d)))throw Error('The file does not match the Intelio draft schema.');
 if(d.schemaVersion!==1||d.mode!=='demo')throw Error('Unsupported schema version or missing demo marker.');
 if(['id','name','description','url','tokenName','tokenSymbol','tokenSupply','updatedAt'].some(x=>typeof d[x]!=='string'))throw Error('Draft text fields must be strings.');
 const errors=validateDraft(d);if(Object.keys(errors).length)throw Error(Object.values(errors)[0]);
 return d;
}
export function readDrafts():Draft[]{
 const raw=localStorage.getItem(APP_KEY);if(!raw)return [];
 const data=JSON.parse(raw);if(!Array.isArray(data))throw Error('Saved drafts could not be read. Export or clear browser data to recover.');
 return data.map(x=>parseDraft(JSON.stringify(x)));
}
export function writeDraft(d:Draft){const drafts=readDrafts();const index=drafts.findIndex(x=>x.id===d.id);const next={...d,updatedAt:new Date().toISOString()};if(index<0)drafts.unshift(next);else drafts[index]=next;localStorage.setItem(APP_KEY,JSON.stringify(drafts));return drafts;}
export function deleteDraft(id:string){const next=readDrafts().filter(x=>x.id!==id);localStorage.setItem(APP_KEY,JSON.stringify(next));return next;}
export function downloadDraft(d:Draft){const blob=new Blob([JSON.stringify(d,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`intelio-${d.id}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}
export function readRuns():Run[]{const r=JSON.parse(localStorage.getItem(RUN_KEY)||'[]');return Array.isArray(r)?r:[];}
export function storeRun(run:Run){const all=readRuns().filter(x=>x.id!==run.id);localStorage.setItem(RUN_KEY,JSON.stringify([run,...all]));}
export function dailyUsage(runs:Run[],draftId:string,day=new Date().toISOString().slice(0,10)){return runs.filter(r=>r.draftId===draftId).flatMap(r=>r.steps).filter(s=>s.at.slice(0,10)===day).reduce((a,s)=>a+s.cost,0);}
export function authorizeStep(step:Step,policy:Draft,balance:number,dailySpent:number){
 if(!policy.tools.includes(step.tool))return `${step.tool} is not permitted.`;
 if(step.cost>policy.requestLimit)return 'Request limit reached.';
 if(dailySpent+step.cost>policy.dailyLimit)return 'Daily allowance reached.';
 if(step.cost>balance)return 'Demo balance exhausted.';
 return null;
}
export function allocate(volume:string,percentages:string[]){
 if(!/^\d{1,10}(\.\d{1,2})?$/.test(volume||'0'))throw Error('Use a nonnegative fee volume with up to two decimal places.');
 if(percentages.length!==4)throw Error('Enter exactly four allocations.');
 const bp=percentages.map(x=>{if(!/^\d{1,3}(\.\d{1,2})?$/.test(x))throw Error('Enter all four percentages with up to two decimal places.');const [a,b='']=x.split('.');return Number(a)*100+Number(b.padEnd(2,'0'));});
 if(bp.some(x=>x>10000)||bp.reduce((a,b)=>a+b,0)!==10000)throw Error('Allocations must total exactly 100%.');
 const [whole,frac='']=(volume||'0').split('.');const total=BigInt(whole)*BigInt(100)+BigInt(frac.padEnd(2,'0'));
 const result=bp.map(x=>total*BigInt(x)/BigInt(10000));let left=total-result.reduce((a,b)=>a+b,BigInt(0));
 const order=bp.map((x,i)=>({i,remainder:total*BigInt(x)%BigInt(10000)})).sort((a,b)=>a.remainder===b.remainder?a.i-b.i:a.remainder>b.remainder?-1:1);
 for(const x of order){if(left<=0)break;result[x.i]++;left--;}
 return {total,amounts:result,bp};
}
export function formatUnits(n:bigint){return `${n/BigInt(100)}.${(n%BigInt(100)).toString().padStart(2,'0')}`;}
export const sampleApps=[
 {id:'atlas',name:'Atlas Research',category:'Research',icon:'research',description:'From scattered sources to a structured research brief.',capabilities:['Text generation','Classification'],tools:['Web research'],units:240,accent:'mint'},
 {id:'sentinel',name:'Sentinel',category:'Monitoring',icon:'monitor',description:'A watchful eye on the signals that matter onchain.',capabilities:['Classification','Embeddings'],tools:['Chain monitor'],units:180,accent:'iris'},
 {id:'forge',name:'Forge Assistant',category:'Development',icon:'code',description:'A focused workspace for understanding and improving code.',capabilities:['Code assistance','Text generation'],tools:['Code analysis'],units:320,accent:'blue'},
 {id:'folio',name:'Folio',category:'Research',icon:'book',description:'Organize documents into useful, searchable knowledge.',capabilities:['Embeddings','Classification'],tools:['Web research'],units:150,accent:'amber'},
 {id:'pulse',name:'Pulse Observer',category:'Monitoring',icon:'activity',description:'Turn illustrative network events into readable summaries.',capabilities:['Text generation','Classification'],tools:['Chain monitor'],units:200,accent:'mint'},
 {id:'syntax',name:'Syntax Lab',category:'Development',icon:'terminal',description:'Explore code explanations with explicit tool permissions.',capabilities:['Code assistance','Classification'],tools:['Code analysis'],units:280,accent:'iris'},
];
export const sampleModels=[
 {name:'Language',category:'Text generation',description:'Draft, summarize and reason over text.',context:'Conversational input',runtime:'Gateway demo'},
 {name:'Classifier',category:'Classification',description:'Map text to a set of useful labels.',context:'Short text input',runtime:'Local example available'},
 {name:'Code',category:'Code assistance',description:'Explain code and structure development tasks.',context:'Code and instructions',runtime:'Gateway demo'},
 {name:'Embedding',category:'Embeddings',description:'Represent text for similarity and retrieval.',context:'Document input',runtime:'Gateway demo'},
];
